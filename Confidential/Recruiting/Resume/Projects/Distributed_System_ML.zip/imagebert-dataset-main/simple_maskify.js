function maskify(tokenization){
    
    return {
        x: 1,
        y: 2,
        width: 2,
        height: 2,
        token: "world",
        word: "hello",
    }
}